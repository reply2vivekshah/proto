import { HuaweiStatusComponent } from './views/status/huawei/huawei-status/huawei-status.component';
import { MikrotikStatusComponent } from './views/status/mikrotik/mikrotik-status/mikrotik-status.component';
import { LoginComponent } from './views/login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [  
  {
    path: "login",
    component: LoginComponent,        
  },
  {
    path: "microtik-status",
    component: MikrotikStatusComponent,    
  },
  {
    path: "huawei-status",
    component: HuaweiStatusComponent,        
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
