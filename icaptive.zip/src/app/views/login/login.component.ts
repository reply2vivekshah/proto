import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  error="";
  vendorParams = {
    "Huawei_Vendor": [
      "userip",
      "apgroup",
      "apip",
      "apmac",
      "apname",
      "devip",
      "devmac",
      "ssid",
      "sysname",      
      "usermac",
      "reurl",
      "loginurl"
    ],
    "Mikrotik_Vendor": [
      "clientIp",
      "loginUrl",
      "userMac",
      "userUrl"
    ]
  };
  detectedVendor={name:"",parameterNames:[],parameters:[],loginUrl:""};
  queryParam: any;
  loginForm = {username:"",password:""};

  constructor(        
    private routes: ActivatedRoute
  ) { }

  ngOnInit() {            
    this.routes.queryParams.subscribe((params) => {
      if (params && !(Object.keys(params).length === 0)) {
        this.queryParam = params;        
        this.detectVendor();        
      }
    });   
  }

  detectVendor(){
    this.resetDetectedVendor();
    var requestParamNamesList = [];
    for(let key in this.queryParam){
      requestParamNamesList.push(key);
    }    
    for(let key in this.vendorParams){
      if(requestParamNamesList.length === this.vendorParams[key].length && this.arrayEquals(requestParamNamesList,this.vendorParams[key])){
        this.detectedVendor.name = key;
        this.detectedVendor.parameterNames = this.vendorParams[key];
        this.detectedVendor.parameters = this.queryParam;
        if(this.detectedVendor.name === 'Mikrotik_Vendor') {         
          this.detectedVendor.loginUrl = this.queryParam['loginUrl'];   
        }else if(this.detectedVendor.name === 'Huawei_Vendor'){
          this.detectedVendor.loginUrl = this.queryParam['loginurl'];
        }                
      }      
    }   
  }

  resetDetectedVendor(){
    this.detectedVendor={name:"",parameterNames:[],parameters:[],loginUrl:""};
  }

  arrayEquals(a, b) {
    a =a.sort();
    b =b.sort();
    return Array.isArray(a) &&
      Array.isArray(b) &&
      a.length === b.length &&
      a.every((val, index) => val === b[index]);
  }
  
  validate() :boolean{        
    let response = true;    
    if(!this.loginForm.username){
      this.error = "please enter username";
      response = false;
    }
    if(!this.loginForm.password){
      this.error = "please enter password";
      response = false;
    }
    return response;
  }

}
