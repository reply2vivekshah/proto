import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mikrotik-status',
  templateUrl: './mikrotik-status.component.html',
  styleUrls: ['./mikrotik-status.component.scss']
})
export class MikrotikStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
