import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MikrotikStatusComponent } from './mikrotik-status.component';

describe('MikrotikStatusComponent', () => {
  let component: MikrotikStatusComponent;
  let fixture: ComponentFixture<MikrotikStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MikrotikStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MikrotikStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
