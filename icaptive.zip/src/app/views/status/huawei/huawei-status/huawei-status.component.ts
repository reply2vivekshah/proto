import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huawei-status',
  templateUrl: './huawei-status.component.html',
  styleUrls: ['./huawei-status.component.scss']
})
export class HuaweiStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
