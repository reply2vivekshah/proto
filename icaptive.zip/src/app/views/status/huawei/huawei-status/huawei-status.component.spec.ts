import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HuaweiStatusComponent } from './huawei-status.component';

describe('HuaweiStatusComponent', () => {
  let component: HuaweiStatusComponent;
  let fixture: ComponentFixture<HuaweiStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HuaweiStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HuaweiStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
