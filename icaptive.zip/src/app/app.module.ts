import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './views/login/login.component';
import { MikrotikStatusComponent } from './views/status/mikrotik/mikrotik-status/mikrotik-status.component';
import { HuaweiStatusComponent } from './views/status/huawei/huawei-status/huawei-status.component';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MikrotikStatusComponent,
    HuaweiStatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,     
    FormsModule,
    CommonModule,
    ReactiveFormsModule,   
    NgbAlertModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
